﻿extends CharacterBody2D

@export var speed: float = 150.0
@export var sprint_speed: float = 250.0

var facing_direction: String = "down"
var is_moving: bool = false

@onready var sprite: Sprite2D = $Sprite2D
@onready var anim_player: AnimationPlayer = $AnimationPlayer

func _ready():
	# 设置初始动画
	play_animation("idle_down")

func _physics_process(delta):
	var input_dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
	
	is_moving = input_dir.length() > 0
	
	# 确定朝向
	if input_dir.x > 0:
		facing_direction = "right"
	elif input_dir.x < 0:
		facing_direction = "left"
	elif input_dir.y > 0:
		facing_direction = "down"
	elif input_dir.y < 0:
		facing_direction = "up"
	
	# 移动
	var current_speed = sprint_speed if Input.is_action_pressed("sprint") else speed
	velocity = input_dir * current_speed
	move_and_slide()
	
	# 播放动画
	if is_moving:
		play_animation("walk_" + facing_direction)
	else:
		play_animation("idle_" + facing_direction)

func play_animation(anim_name: String):
	if anim_player.has_animation(anim_name):
		anim_player.play(anim_name)

func _input(event):
	if event.is_action_pressed("action_interact"):
		interact()

func interact():
	# 在面朝方向检测可交互物体
	var interact_pos = global_position
	match facing_direction:
		"up": interact_pos.y -= 32
		"down": interact_pos.y += 32
		"left": interact_pos.x -= 32
		"right": interact_pos.x += 32
	
	# 这里可以添加与作物、工具等交互的逻辑
	print("尝试在位置交互: ", interact_pos)
